#version 2.10.9
if ! echo $PATH | /bin/grep -q /usr/local/ncbi/sra-tools/bin
then export PATH=/usr/local/ncbi/sra-tools/bin:$PATH
fi